//
//  ImageViewController.swift
//  resimYukleme
//
//  Created by Ferhat Bolat on 4.01.2023.
//

import UIKit

class ImageViewController: UIViewController {
    var gelenImage = Data()
  
    @IBOutlet var imageGoster: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        print(gelenImage)
        
        if let image = UIImage(data: gelenImage) {
            imageGoster.image = image
        }
        
    }
    

   

}
