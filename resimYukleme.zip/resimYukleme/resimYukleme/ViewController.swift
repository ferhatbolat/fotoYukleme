//
//  ViewController.swift
//  resimYukleme
//
//  Created by Ferhat Bolat on 19.12.2022.
//

import UIKit
import Alamofire
typealias Parameters = [String: String]
class ViewController: UIViewController {
    var veri: UIImageView!
    @IBOutlet var btnMedia: UIButton!
    @IBOutlet var ivImage: UIImageView!
    let imagePicker = UIImagePickerController()
    var body = Data()
    var imageData = Data()

    override func viewDidLoad() {
        super.viewDidLoad()
        imagePicker.delegate = self
               imagePicker.sourceType = .photoLibrary
               imagePicker.mediaTypes = ["public.image", "public.movie"]
               
               btnMedia.addTarget(self, action: #selector(onBtnMediaClicked(_:)), for: .touchUpInside)
    }

    @IBAction func veriTasiBtn(_ sender: Any) {
        performSegue(withIdentifier: "goGoster", sender: Any?.self)
        print(imageData)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let detailVC = segue.destination as? ImageViewController { // 1
            detailVC.gelenImage = imageData     // 2
               }
    }
    
    @IBAction func onBtnMediaClicked(_ sender: UIButton) {
        let optionMenu = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        
        let btnCamera = UIAlertAction(title: "Kamera", style: .default) {
            (action) in
            self.imagePicker.sourceType = .camera
            self.present(self.imagePicker, animated: true)
            }
        let btnGallery = UIAlertAction(title: "Galeri", style: .default) {
            (action) in
                  self.imagePicker.sourceType = .photoLibrary
                  self.present(self.imagePicker, animated: true)
              }
        
        let btnCancel = UIAlertAction(title: "Vazgeç", style: .destructive) {
            (action) in
                  
              }
              optionMenu.addAction(btnCamera)
              optionMenu.addAction(btnGallery)
              optionMenu.addAction(btnCancel)
              self.present(optionMenu, animated: true)
    }
        
    
    @IBAction func yukle(_ sender: Any) {
      
    
    
    }
      
      func Yukle1(){
          
              let url = "http://78.135.83.129/api/v1/adverts?description=AdvertDescription&collection_name=AdvertCollectionName&is_valid=1&currency_id=1&category_id=2&user_id=2&date_of_purchase=2021-12-14&warranty_end_date=2023-12-14&product_status_id=1&advert_status_id=1&warranty=1&name=AdvertName&price=555&type=null&bargaining_status=1&image=a"
             let parameters = ["name": "rname"] //Optional for extra parameter
          let token = "7|sPjdRaJ2bVSZP4Mb2BNDrQpEhDblVDmcbuU4t3oS"
          let headers: HTTPHeaders = [.authorization(bearerToken: token)]

             AF.upload(multipartFormData: { multipartFormData in
             multipartFormData.append(imageData, withName: "fileset",fileName: "file.jpg", mimeType: "image/jpg")
             for (key, value) in parameters {
             multipartFormData.append(value.data(using: String.Encoding.utf8)!, withName: key)
             } //Optional for extra parameters
             },
             to:"mysite/upload.php")
             { (result) in
             switch result {
             case .success(let upload, _, _):

             upload.uploadProgress(closure: { (progress) in
             print("Upload Progress: \(progress.fractionCompleted)")
             })

             upload.responseJSON { response in
             print(response.result.value)
             }

             case .failure(let encodingError):
             print(encodingError)
             }
             }
      }
      
      
      func fotoYukle2 () {
          let parameters = ["name": "rname"] //Optional for extra parameter
          AF.upload(multipartFormData: { multipartFormData in
                  multipartFormData.append(imageData, withName: "fileset",fileName: "file.jpg", mimeType: "image/jpg")
                  for (key, value) in parameters {
                  multipartFormData.append(value.data(using: String.Encoding.utf8)!, withName: key)
                  } //Optional for extra parameters
                  },
                  to:"mysite/upload.php")
                  { (result) in
                  if result.isSuccess {
                      let upload = result.value!
                      upload.uploadProgress(closure: { (progress) in
                      print("Upload Progress: \(progress.fractionCompleted)")
                      })

                      upload.responseJSON { response in
                      print(response.result.value)
                      }
                  } else {
                      print(result.error)
                  }
              }
      }
      
      func fotoyukle3 (){
          let parameters = ["name": "rname"] //Optional for extra parameter
          AF.upload(multipartFormData: { multipartFormData in
                  multipartFormData.append(imageData, withName: "fileset",fileName: "file.jpg", mimeType: "image/jpg")
                  for (key, value) in parameters {
                  multipartFormData.append(value.data(using: String.Encoding.utf8)!, withName: key)
                  } //Optional for extra parameters
                  },
                  to:"mysite/upload.php")
                  { (result) in
                  if let upload = result.value {
                      upload.uploadProgress(closure: { (progress) in
                      print("Upload Progress: \(progress.fractionCompleted)")
                      })

                      upload.responseJSON { response in
                      print(response.result.value)
                      }
                  } else {
                      print(result.error)
                  }
              }
      }
      func UPLOD()
          {
              //Parameter HERE
              let parameters = [
                  "id": "429",
                  "docsFor" : "visitplan"
              ]
              //Header HERE
              let headers = [
                  "token" : "W2Y3TUYS0RR13T3WX2X4QPRZ4ZQVWPYQ",
                  "Content-type": "multipart/form-data",
                  "Content-Disposition" : "form-data"
              ]
              /**
               let image = UIImage.init(named: "furkan")
               let imgData = UIImageJPEGRepresentation(image!, 0.7)!
               **/
              
              
              AF.upload(multipartFormData: { multipartFormData in
                  //Parameter for Upload files
                  multipartFormData.append(imageData, withName: "file",fileName: "furkan.png" , mimeType: "image/png")
                  
                  for (key, value) in parameters
                  {
                      multipartFormData.append(value.data(using: String.Encoding.utf8)!, withName: key)
                  }
                  
              }, usingThreshold:UInt64.init(),
                 to: "http:API-for-url-her", //URL Here
                  method: .post,
                  headers: headers, //pass header dictionary here
                  encodingCompletion: { (result) in
                      
                      switch result {
                      case .success(let upload, _, _):
                          print("the status code is :")
                          
                          upload.uploadProgress(closure: { (progress) in
                              print("something")
                          })
                          
                          upload.responseJSON { response in
                              print("the resopnse code is : \(response.response?.statusCode)")
                              print("the response is : \(response)")
                          }
                          break
                      case .failure(let encodingError):
                          print("the error is  : \(encodingError.localizedDescription)")
                          break
                      }
              })
          }
      
      
      
      
      
      
      
    
    
    
    
/************************************************************/
    
    @IBAction func getRequest(_ sender: Any) {
        guard let url = URL(string: "https://jsonplaceholder.typicode.com/users") else { return }
        var request = URLRequest(url: url)
        
        let boundary = generateBoundary()
        
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        let dataBody = createDataBody(withParameters: nil, media: nil, boundary: boundary)
        request.httpBody = dataBody
        
        let session = URLSession.shared
        session.dataTask(with: request) { (data, response, error) in
            if let response = response {
                print(response)
            }
            
            if let data = data {
                do {
                    let json = try JSONSerialization.jsonObject(with: data, options: [])
                    print(json)
                } catch {
                    print(error)
                }
            }
        }.resume()
        
    }
    
    
    @IBAction func postRequest(_ sender: Any) {
        print("press post")
        
        let parameters = ["name": "MyTestFile123321",
                          "description": "My tutorial test file for MPFD uploads"]
        
        guard let mediaImage = Media(withImage: #imageLiteral(resourceName: "Image"), forKey: "image") else {
            print("hata")
            return }
        
        guard let url = URL(string: "https://api.imgur.com/3/image") else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        print("1")
        let boundary = generateBoundary()
        
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        request.addValue("Client-ID f65203f7020dddc", forHTTPHeaderField: "Authorization")
        print("2")
        let dataBody = createDataBody(withParameters: parameters, media: [mediaImage], boundary: boundary)
        request.httpBody = dataBody
        print("3")
        let session = URLSession.shared
        print("4")
        session.dataTask(with: request) { (data, response, error) in
            if let response = response {
                print(response)
                print("5")
            }
            
            if let data = data {
                do {
                    let json = try JSONSerialization.jsonObject(with: data, options: [])
                    print(json)
                } catch {
                    print(error)
                }
            }
            }.resume()
    }
    
    func generateBoundary() -> String {
        return "Boundary-\(NSUUID().uuidString)"
    }
    
    func createDataBody(withParameters params: Parameters?, media: [Media]?, boundary: String) -> Data {
        
        let lineBreak = "\r\n"
        var body = Data()
        
        if let parameters = params {
            for (key, value) in parameters {
                body.append("--\(boundary + lineBreak)")
                body.append("Content-Disposition: form-data; name=\"\(key)\"\(lineBreak + lineBreak)")
                body.append("\(value + lineBreak)")
            }
        }
        
        if let media = media {
            for photo in media {
                body.append("--\(boundary + lineBreak)")
                body.append("Content-Disposition: form-data; name=\"\(photo.key)\"; filename=\"\(photo.filename)\"\(lineBreak)")
                body.append("Content-Type: \(photo.mimeType + lineBreak + lineBreak)")
                body.append(photo.data)
                body.append(lineBreak)
            }
        }
        
        body.append("--\(boundary)--\(lineBreak)")
        
        return body
    }
    
/************************************************************/
    
    
}
/******************************************************/
extension Data {
    mutating func append(_ string: String) {
        if let data = string.data(using: .utf8) {
            append(data)
        }
    }
}




/******************************************************/

extension ViewController: UIImagePickerControllerDelegate & UINavigationControllerDelegate{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            let mediaType = info[.mediaType] as? String
            switch mediaType {
            case "public.movie":
                if let videoUrl = info[.mediaURL] as? NSURL {
                    // TODO : set video to avplayer
                    print(videoUrl)
                }
            case "public.image":
                if let image = info[.originalImage] as? UIImage {
                    ivImage.image = image
                     imageData = image.jpegData(compressionQuality: 0.5)!
                    let boundary = "Boundary-\(UUID().uuidString)"
                    print(boundary)
                
                    
                }
                
            default:
                break
            }
            self.dismiss(animated: true)
        }
}
